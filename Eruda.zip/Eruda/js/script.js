var number = document.getElementById('number');
number.value;

number = 10;
number = 'Hello';

console.log(`${number}`);